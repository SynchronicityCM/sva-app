"""
Submission handler — JSON download
Synchronicity Change Management · April 2026
No email service required.
"""

import json
from datetime import datetime


def save_submission(participant_name, access_code, scored_data, raw_data):
    """
    Package submission as JSON string for download.
    Returns (success, json_string or error).
    """
    try:
        submission = {
            'instrument': 'SVA',
            'version': '2.0',
            'participant_name': participant_name,
            'access_code': access_code,
            'submitted_at': datetime.utcnow().isoformat(),
            'raw_data': raw_data,
            'scored_data': scored_data,
        }
        json_str = json.dumps(submission, indent=2, ensure_ascii=False)
        return True, json_str
    except Exception as e:
        return False, str(e)


def submit_via_sendgrid(participant_name, access_code, scored_data, raw_data):
    return save_submission(participant_name, access_code, scored_data, raw_data)


def save_local_backup(participant_name, access_code, scored_data, raw_data):
    return save_submission(participant_name, access_code, scored_data, raw_data)
